document.addEventListener('DOMContentLoaded', function() {
  const botonMenu = document.getElementById('ver-menu-btn');
  
  botonMenu.addEventListener('click', function() {
    window.location.href = 'menú.html';
  });
});